package ru.rgrtu;

import static ru.rgrtu.AskMe.answer;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Question q = new Question();
        answer(q.ask());
        answer(q.ask());
        answer(q.ask());
        answer(q.ask());
    }
}
