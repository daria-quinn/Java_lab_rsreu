package ru.rgrtu;

public enum Answers {
    NO, YES, MAYBE, LATER, SOON, NEVER
}
