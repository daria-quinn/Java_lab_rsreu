package appfuncs.simplefuncs;

// Несколько простых математических функций
public class SimpleMathFuncs {

    // Определяет, является ли a кратным b
    public static boolean isFactor(int a, int b) {
        if ((b%a) == 0) return true;
        return false;
    }

    // Возвращает наименьшее общее кратное для a и b
    public static int lcf(int a, int b) {
        a = Math.abs(a);
        b = Math.abs(b);

        int min = a < b ? a : b;

        for (int i = 2; i <= min/2; i++) {
            if (isFactor(i, a) && isFactor(i, b))
                return i;
        }
        return 1;
    }

    // Возвращает наибольшее общее кратное для a и b
    public static int gcf(int a, int b) {
        a = Math.abs(a);
        b = Math.abs(b);

        int min = a < b ? a : b;

        for (int i = 2; i >= 2; i--) {
            if (isFactor(i, a) && isFactor(i, b))
                return i;
        }
        return 1;
    }
}
