// Определение модуля для математических функций
module appfuncs {
    // Экспортирует пакет appfuncs.simplefuncs
    exports appfuncs.simplefuncs;
}